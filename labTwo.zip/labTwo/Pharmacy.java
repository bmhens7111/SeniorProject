package labTwo;

public class Pharmacy extends InvOrg {
protected String desc;
	public Pharmacy (String InvName, double InvPrice, int InvId, String InvPharm) {
		super(InvName, InvPrice, InvId);
		desc = InvPharm;
	}
	
	public void setDesc(String InvPharm){
		desc = InvPharm;
	}
	
	public String getDesc(){
		return desc;
	}
	
	public String toString (){
		return super.toString()+" is a "+ desc +" product";
	}
	
	public void bigPharma(){
		System.out.println(name + "costs "+ price+"and is a "+ desc+"prouduct.");
	}
}
