package labTwo;

public class Health extends Pharmacy {
protected String expInxp;
	public Health(String InvName, double InvPrice, int InvId, String InvPharm, String InvHealth) {
		super(InvName, InvPrice, InvId, InvPharm);
		expInxp = InvHealth;
	}
		
	public void setInvHealth(String InvHealth){
			expInxp = InvHealth;
		}
	
	public String getInvHealth(){
		return expInxp;
	}

	public String toString(){
		return super.toString()+ ", is "+ expInxp;	
	}
	
	public void HealthExtra(){
		System.out.println("is healthy!"); 
	}
}
