package labTwo;

public class Cleaning extends Household {
protected String example;
public Cleaning(String InvName, double InvPrice, int InvId,String InvHouse, String InvClean) {
	super(InvName, InvPrice, InvId, InvHouse);
	example = InvClean;
}
	public void setInvClean(String InvClean){
		example = InvClean;
	}

	public String getInvClean(){
	return example;
	}

	public String toString(){
	
		return super.toString()+ ", is "+ example;	
	}
	
	public void CleaningExtra(){
		System.out.println("gets things spiffy!"); 
	}
}


