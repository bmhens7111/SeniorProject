package labTwo;

public class InvOrg {
	protected String name;
	protected double price;
	protected int id;
	
	public InvOrg( String InvName, double InvPrice, int InvId){
		name = InvName;
		price = InvPrice;
		id = InvId;
	}

	public void setName(String InvName){
		name = InvName;
	}

	public String getName(){
		return name;
	}

	public void setPrice(double InvPrice){
		price = InvPrice;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setId (int InvId){
		id = InvId;
	}

	public int getId (){
		return id;
	}
	public String toString(){
		return name +", " + id + ", " +"$"+ price + ",";
	}
}
