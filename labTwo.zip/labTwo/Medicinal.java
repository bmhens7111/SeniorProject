package labTwo;

public class Medicinal extends Pharmacy {
protected boolean isLiq;
	public Medicinal(String InvName, double InvPrice, int InvId, String InvPharm, boolean InvMed) {
		super(InvName, InvPrice, InvId, InvPharm);
		isLiq = InvMed;
	}
	 
	public void setLiqSol(boolean InvMed){
		isLiq = InvMed;
	}
	
	public boolean getLiqSol(){
		return isLiq;
	}
	
	public String toString(){
		return super.toString()+ " liquid " + isLiq;	
	}
	
	public void LiqOrSol(boolean InvMed){
		System.out.println( name + "is");
		if (!isLiq){
			System.out.println(" not a liquid.");
		}
		else System.out.println(" is a liquid.");
	}

}
