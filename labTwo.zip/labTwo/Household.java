package labTwo;

public class Household extends InvOrg {
protected String info;
	public Household(String InvName, double InvPrice, int InvId, String InvHouse) {
		super(InvName, InvPrice, InvId);
		info = InvHouse;
	}
	
	public void setInfo(String InvHouse){
		info = InvHouse;
	}
	
	public String getInfo(){
		return info;
	}
	
	public String toString (){
		return super.toString()+ " is a "+ info +" product"; //classify if *name* is a(n) cleaning or electronic product
	}
	
	public void householdExtra(){
		System.out.println(name + "costs "+ price+"and is a "+ info +" prouduct, "); //cleaning or electronic product
	}
}

