package labTwo;

public class Electronics extends  Household{
protected String zipyy; 
	public Electronics(String InvName, double InvPrice, int InvId,String InvHouse, String InvElec) {
		super(InvName, InvPrice, InvId, InvHouse);
		zipyy = InvElec;
	}
	public void setInvElec(String InvElec){
		zipyy = InvElec;
		}
	
	public String getInvElec(){
		return zipyy;
		}
	
	public String toString(){
		return super.toString()+ ", is "+ zipyy;	
		}
	
	public void ElectronicsExtra(){
		System.out.println("is cool!");
	}
}
	
