package labTwo;
import java.util.Scanner;

public class WalmartMainMethod {
	
	//binary search method
		 static int binarySearch(Object[] arr, int x) 
		    { 
		        int leftIndex = 0, rightIndex = arr.length - 1; 
		        Integer y = new Integer(x);
		        while (leftIndex <= rightIndex) { 
		            int middleIndex = leftIndex + (rightIndex - leftIndex) / 2; 
		  
		            int res = y.compareTo(((InvOrg) arr[middleIndex]).getId());
		           
		            if (res == 0) 
		                return middleIndex; 
		  
		            if (res > 0) 
		                leftIndex = middleIndex + 1; 
		  
		            else
		                rightIndex = middleIndex - 1; 
		        } 
		  
		        return -1; 
		    }

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		String search;
		// invorg objects
		InvOrg tires = new InvOrg ("Tires", 20.06, 102);
		InvOrg oil = new InvOrg ("Oil", 10.02, 410);

		// household objects
		Household fridge = new Household ("Fridge", 679.99, 857, "silver");
		Household fan = new Household ("Fan", 34.05, 290, "white");

		// pharmacy objects
		Pharmacy protein = new Pharmacy ("Protein", 6.99, 111, "chocolate");
		Pharmacy vitamins = new Pharmacy ("Vitamins", 8.99, 401, "gummy");

		// cleaning objects
		Cleaning ptowels = new Cleaning ("Paper towels", 2.99, 910, "bounty", "family sized.");
		Cleaning bleach = new Cleaning ("Bleach", 4.99, 310, "clorox", "whitening.");

		// electronics objects

		Electronics tv = new Electronics ("Tv", 670.99, 810, "samsung", "widescreen");
		Electronics playstation = new Electronics ("Playstation", 999.99, 690, "1 TB", "black");

		// medicinal objects

		Medicinal advil = new Medicinal ("Advil", 4.99, 909, "small bottle", false);
		Medicinal tums = new Medicinal ("Tums", 4.21, 420, "pink", true);

		// health objects

		Health bandaids = new Health ("Bandaids", 3.99, 191, "waterproof", "skincolored");
		Health peroxide = new Health ("Peroxide", 5.99, 830, "industrial", "spray");

		

		//Array
				Object[] prodArray = {1,2,3,4,5,6,7,8,9,10,11,12,13,14};
				
				prodArray[0] = tires;
				prodArray[1] = oil;
				prodArray[2] = fridge;
				prodArray[3] = fan;
				prodArray[4] = protein;
				prodArray[5] = vitamins;
				prodArray[6] = ptowels;
				prodArray[7] = bleach;
				prodArray[8] = tv;
				prodArray[9] = playstation;
				prodArray[10] = advil;
				prodArray[11] = tums;
				prodArray[12] = bandaids;
				prodArray[13] = peroxide;
				
				// print array loop
				for (int i = 0; i < prodArray.length; i++) {
					System.out.println(prodArray[i]);
				}
	
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(" ");
				
				System.out.println("Please enter the name of the product to see its information.");
				search = scnr.next();
				
				//System.out.println(((InvOrg) prodArray[0]).getName());
				
				//Search name and ouput product info
				for(int i=0; i<prodArray.length;i++){
				if (((InvOrg) prodArray[i]).getName().equals(search) ){
					System.out.println(prodArray[i]);
				} 
				}
				System.out.println(" ");
				System.out.println(" ");
				System.out.println(" ");
				
				
				
				//sort array based on price
				Object tempT;
				for( int i =0; i < prodArray.length -1; i++  )
				{
					int assume_min_index = i;

					for( int smallest_index = i +1; smallest_index < prodArray.length; smallest_index++ )
					{
						if (((InvOrg) prodArray[assume_min_index]).getPrice()>((InvOrg) prodArray[smallest_index]).getPrice() )
							assume_min_index = smallest_index;
					}
					tempT = prodArray[i];
					prodArray[i] = prodArray[ assume_min_index  ];
					prodArray[ assume_min_index  ] = tempT;

				}
	
							System.out.println("Here is the array sorted based on products' Price:");
							
							for (int i = 0; i < prodArray.length; i++) {
								System.out.println(prodArray[i]);
							}
				

							System.out.println(" ");
							System.out.println(" ");
							System.out.println(" ");
				
				//Sort array based on ID
				
				Object temp;
				for( int i =0; i < prodArray.length -1; i++  )
				{
					int assume_min_index = i;

					for( int smallest_index = i +1; smallest_index < prodArray.length; smallest_index++ )
					{
						if (((InvOrg) prodArray[assume_min_index]).getId()>((InvOrg) prodArray[smallest_index]).getId() )
							assume_min_index = smallest_index;
					}
					temp = prodArray[i];
					prodArray[i] = prodArray[ assume_min_index  ];
					prodArray[ assume_min_index  ] = temp;

				}
	
							System.out.println("Here is the array sorted based on products' ID:");
							
							for (int i = 0; i < prodArray.length; i++) {
								System.out.println(prodArray[i]);
							}
	
	
							System.out.println(" ");
							System.out.println(" ");
							System.out.println(" ");
							
							
							//Integrate binary Search method
							System.out.println("Please enter the ID to know its info:");
							int keyNumber = scnr.nextInt();
							
							int result = binarySearch(prodArray, keyNumber);
			    	    	if(  result == -1)
			    	    		System.out.println("No " + keyNumber + " in the array");
			    	    	else
			    	    		for(int i=0; i<prodArray.length;i++){
			    					if (((InvOrg) prodArray[i]).getId()==keyNumber ){
			    						System.out.println(prodArray[i]);
			    						
			    					}
			    					
			    	    		} 
	
	
	
	
	
	}

					}
