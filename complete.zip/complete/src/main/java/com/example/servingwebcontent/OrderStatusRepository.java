package com.example.servingwebcontent;


import org.springframework.data.repository.CrudRepository;
 
public interface OrderStatusRepository extends CrudRepository<OrderStatus, Long> {
 
}