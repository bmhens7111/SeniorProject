package com.example.servingwebcontent;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity // This tells Hibernate to make a table out of this class
@Table(name = "appointment") //This specifies the primary table for the annotated entity in MySQL. MAKE SURE YOUR NAMES MATCH IN YOUR SQL 

public class Appointment {
    @Id //Specifies the primary key of an entity.
    @Column(name = "appointment_id") //Specifies the mapped column for a persistent property or field.
    @GeneratedValue(strategy=GenerationType.AUTO) //The GeneratedValue annotation may be applied to a primary key property or field of an entity or mapped superclass in conjunction with the Id annotation
    private Integer appointmentId;
    private String appttime;
    private String Tech;
    private String Radio;
    private Integer orderId;
    private Integer checked_in;
    @Transient
    Patient patientObject;
    public Integer getOrderId() {
        return orderId;
    }

    public Integer getChecked_in(){
        return this.checked_in;
    }

    public void setChecked_in(Integer checked_in){
        this.checked_in = checked_in;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }
    public Integer getAppointmentId(){
        return this.appointmentId;
    }
    public void setAppointmentId(Integer appointmentId)
    {
        this.appointmentId = appointmentId;
    }
    public String getAppttime(){
        return this.appttime;
    }
    public void setAppttime(String appttime)
    {
        this.appttime = appttime;
    }
    public String getTech(){
        return this.Tech;
    }
    public void setTech(String Tech){
        this.Tech = Tech;
    }
    public String getRadio(){
        return this.Radio;
    }
    
    public void setRadio(String Radio){
        this.Radio = Radio;
    }
    public Patient getPatient(){
        return this.patientObject;
    }
    public void setPatientObject(Patient patientObject){
        this.patientObject = patientObject;
    }

}