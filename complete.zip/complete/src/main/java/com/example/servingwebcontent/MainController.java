package com.example.servingwebcontent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.example.servingwebcontent.model.DBFile;
import com.example.servingwebcontent.repository.DBFileRepository;
import com.example.servingwebcontent.service.DBFileStorageService;

@Controller
public class MainController {
   @Autowired
   DiagnosticReportRepository diagnosticReportRepository;
   @Autowired
   PatientRepository patientRepository;
   @Autowired
   RoleRepository roleRepository;
   @Autowired
   DBFileStorageService dbFileStorageService;
   @Autowired
   DBFileRepository dbFileRepository;
   @Autowired
   OrderRepository orderRepository;
   @Autowired 
   AppointmentRepository appointmentRepository;
   @Autowired
   OrderStatusRepository orderStatusRepository;
   @Autowired
   EmployeeRepository employeeRepository;


   @GetMapping("/createPatient")
   public String createProjectForm(Model model) {

      model.addAttribute("patient_list", patientRepository.findAll());
      model.addAttribute("patient", new Patient());
      model.addAttribute("order_list", orderRepository.getAllOrdersByStatus(Integer.valueOf(1)));
      model.addAttribute("order", new Order());
      return "createPatientOrder";
   }

   @GetMapping("/searchPatients")
      public String searchPage(Model model)
      {
         return "searchPatients";
      }
   @PostMapping("/savePatientInfo")
   public String addNewPatient(@ModelAttribute("patient") Patient patient, Model model)
   {
      patientRepository.save(patient);
      return "redirect:/createPatient";
   }
   @PostMapping("/saveReport")
      public String saveReport(@ModelAttribute("diagnosticReport") DiagnosticReport diagnosticReport, Model model)
      {
         Optional<Order> findOrder = orderRepository.findById(diagnosticReport.getOrder_id());
         if(findOrder.isPresent())
         {
            Order order = findOrder.get();
            order.setStatus(5);
            diagnosticReportRepository.save(diagnosticReport);
            orderRepository.save(order);
         }
         return "redirect:/radiologistsPanel";
      }
      @PostMapping("/saveOrder")
      public String saveOrder(@ModelAttribute("order") Order order, @ModelAttribute("patient") Patient patient, Model model)
      {
         order.setPatient_id(patient.getPatientId());
         order.setStatus(1);
         System.out.println("PATIENT PP _____"+order.getPatientId());
         Order newOrder = orderRepository.save(order);
         return "redirect:/refDrPanel";
      }
      @PostMapping("/saveAppointment")
      public String addNewAppt(@ModelAttribute("appointment") Appointment appointment, Model model)
      {
         appointment.setChecked_in(0);
         Appointment newAppointment = appointmentRepository.save(appointment);
         System.out.println("APPOINTMENT : " + appointment.getOrderId());
         Optional<Order> findOrder = orderRepository.findById(Long.valueOf(appointment.getOrderId()));
         
         if(findOrder.isPresent())
         {
            Order order = findOrder.get();
            order.setStatus(2);
            orderRepository.save(order);
         }
         return "redirect:/receptionistsPanel";
      }

    @GetMapping("/login")
	public String viewLoginPage(Model model)
	{
		model.addAttribute("user", new User());
		return "login";
	}

   @GetMapping("/home")
   public String home(Model model)
   {       
     User loggedInUser = ((MyUserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUser();
      Set<Role> userRoles = loggedInUser.getRoles();

      System.out.println(loggedInUser.getId());

      System.out.println(userRoles.size());

      for(Role role : roleRepository.findAll())
      {
         System.out.println(role.getName());
      }
      for(OrderStatus status : orderStatusRepository.findAll())
      {
         System.out.println(status.getId());
      }
      for(Role role : userRoles)
      {
         System.out.println(role.getName());
         if(role.getId() == 1)      //  ADMIN
         {
            return "redirect:/adminPanel";
         }
         else if(role.getId() == 2)
         {
            return "redirect:/refDrPanel";
         }
         else if(role.getId() == 3)
         {
            return "redirect:/techPanel";
         }
         else if(role.getId() == 4)
         {
            return "redirect:/radiologistsPanel";
         }
         else if(role.getId() == 5)
         {
            return "redirect:/receptionistsPanel";
         }      
      }



      model.addAttribute("patient_list", patientRepository.findAll());
      model.addAttribute("patient", new Patient());

      return "createPatientOrder";
   }

   @PostMapping("/saveEmpInfo")
   public String saveEmpInfo(@ModelAttribute("employee") Employee employee, BindingResult result, Model model)
   {
      Employee newEmployee = employeeRepository.save(employee);
      return "redirect:/adminBackendPage";
   }
   @GetMapping("/adminPanel")
   public String adminPanel(Model model)
   {
      model.addAttribute("order_list_completed", orderRepository.getAllOrdersByStatus(Integer.valueOf(5)));
      model.addAttribute("order_list", orderRepository.getAllOrdersByStatus(Integer.valueOf(1)));

      model.addAttribute("dbFiles", dbFileStorageService.listAllFiles());
      model.addAttribute("report_list", diagnosticReportRepository.findAll());
      model.addAttribute("diagnosticReport", new DiagnosticReport());
      model.addAttribute("patient_list", patientRepository.findAll());
      model.addAttribute("patient", new Patient());
      return "adminPanel";
   }
   @GetMapping("/refDrPanel")
   public String refDrPanel(Model model)
   {

      Iterable<Patient> patient_list = patientRepository.findAll();
      for(Patient patient : patient_list)
      {
         //patient.setReport(diagnosticReportRepository.getAllFilesByOrderId(patient.getPatientId()));
         //System.out.println("Report: " + patient.getReport());
      }
      model.addAttribute("order_list_completed", orderRepository.getAllOrdersByStatus(Integer.valueOf(5)));
      model.addAttribute("order_list", orderRepository.getAllOrdersByStatus(Integer.valueOf(1)));

      model.addAttribute("dbFiles", dbFileStorageService.listAllFiles());
      model.addAttribute("report_list", diagnosticReportRepository.findAll());
      model.addAttribute("diagnosticReport", new DiagnosticReport());
      model.addAttribute("patient_list", patientRepository.findAll());
      model.addAttribute("patient", new Patient());
      return "refDrPanel";
   }
   @GetMapping("/adminBackendPage")
   public String adminBackendPageButton(Model model)
   {
      model.addAttribute("employee_list", employeeRepository.findAll());
      model.addAttribute("employee", new Employee());
      return "adminBackendPage";
   }

   @PostMapping("/searchPatients")
   public String searchPatient(@ModelAttribute Patient patient, Model model)
   {
       System.out.println(patient.getDOB());
       Iterable<Patient> patient_list = patientRepository.getPatientByDOB(patient.getDOB());
       for(Patient pat : patient_list)
       {
          System.out.println(pat.getEmail());
       }
       model.addAttribute("patient_list", patientRepository.getPatientByDOB(patient.getDOB()));
       model.addAttribute("patient", new Patient());
       model.addAttribute("order", new Order());

       return "searchPatients";
   }
   @GetMapping("/createPatientOrder")
   public String createPatientOrderButton(Model model)
   {
      return "createPatientOrder";
   }
   @GetMapping("/radiologistsPanel")
   public String radiologistsPanel(Model model)
   {
      Iterable<Patient> patient_list = patientRepository.findAll();
      for(Patient patient : patient_list)
      {
         //patient.setFileList(dbFileRepository.getAllFileUploadsByOrderId(patient.getPatientId()));
         //System.out.println("File list: " + patient.getFileList());
      }
      ArrayList<Order> order_list = new ArrayList<Order>();
      for(Appointment appointment : appointmentRepository.getCheckedInAppointments())
      {
         Optional<Order> findOrder = orderRepository.findById(Long.valueOf(appointment.getOrderId()));
         if(appointment.getChecked_in() == 1 && findOrder.isPresent())
         {
            System.out.println("PATIENT+++++++++++++++++++++++++++" + findOrder.get().getPatientId());
            findOrder.get().setPatientObject((patientRepository.findById(findOrder.get().getPatientId()).isPresent()) ? (patientRepository.findById(findOrder.get().getPatientId()).get()) : new Patient());
            order_list.add(findOrder.get());
         }
      }

      Iterable<Order> ready_orders_list = orderRepository.getAllOrdersByStatus(Integer.valueOf(4));
      for(Order order : ready_orders_list)
      {
         order.setFileList(dbFileRepository.getAllFileUploadsByOrderId(order.getId()));
      }


      model.addAttribute("order_list", ready_orders_list);

      model.addAttribute("patient_list", patient_list);
      model.addAttribute("patient", new Patient());
      model.addAttribute("dbFiles", dbFileStorageService.listAllFiles());
      model.addAttribute("report_list", diagnosticReportRepository.findAll());
      model.addAttribute("diagnosticReport", new DiagnosticReport());
	   return "radiologistsPanel";
   }

   @GetMapping("/receptionistsPanel")
   public String receptionistsPanel(Model model)
   {
      /*Iterable<Order> order_list = orderRepository.findAll();
      for(Order order : order_list)
      {
         order.setPatientLastName(OrderRepository.getAllPatients(order.getPatientLastName()));
         System.out.println("Patient Order List: " + order.getPatientLastName());
      }*/

      //  Find today's appointments

      Iterable<Appointment> appointments_list = appointmentRepository.findAll();
      ArrayList<Appointment> todays_appointments_list = new ArrayList<Appointment>();

      for(Appointment appointment : appointments_list) 
      {
          String datetime = appointment.getAppttime();
          String date = datetime.split(" ")[0];
          String today = LocalDate.now().toString();
          System.out.println(date);
          System.out.println(today);
          System.out.println(appointment.getChecked_in());

          if(date.equals(today) && appointment.getChecked_in() != 1)
          {
              todays_appointments_list.add(appointment);
          }
      }
      model.addAttribute("order_list", orderRepository.getAllOrdersByStatus(Integer.valueOf(1)));

      model.addAttribute("todays_appointments_list", todays_appointments_list);
      
      model.addAttribute("order", new Order());
      model.addAttribute("appointment_list", appointmentRepository.findAll());
      model.addAttribute("appointment", new Appointment());
      model.addAttribute("patient_list", patientRepository.findAll());
      model.addAttribute("patient", new Patient());
	   return "receptionistsPanel";
   }

   @GetMapping("/techPanel")
   public String techPanel(Model model)
   {
      ArrayList<Order> order_list = new ArrayList<Order>();
      for(Appointment appointment : appointmentRepository.getCheckedInAppointments())
      {
         Optional<Order> findOrder = orderRepository.findById(Long.valueOf(appointment.getOrderId()));
         if(appointment.getChecked_in() == 1 && findOrder.isPresent())
         {
            order_list.add(findOrder.get());
         }
      }

      
      Iterable<Order> ready_orders_list = orderRepository.getAllOrdersByStatus(Integer.valueOf(3));
      for(Order order : ready_orders_list)
      {
         order.setFileList(dbFileRepository.getAllFileUploadsByOrderId(order.getId()));
      }

      model.addAttribute("order_list", ready_orders_list);

      model.addAttribute("appointment_list", appointmentRepository.findAll());
      model.addAttribute("appointment", new Appointment());
      model.addAttribute("patient_list", patientRepository.findAll());
      model.addAttribute("patient", new Patient());
      model.addAttribute("order", new Order());


	   return "techPanel";
   }  
   @PostMapping("/checkin")
   public String checkInButton(@ModelAttribute("appointment") Appointment appointment, Model model)
   {
      Optional<Appointment> findApppointment = appointmentRepository.findById(Integer.valueOf(appointment.getAppointmentId()));
      if(findApppointment.isPresent())
      {
         Appointment foundAppointment = findApppointment.get();
         foundAppointment.setChecked_in(1);

         Optional<Order> findOrder = orderRepository.findById(Long.valueOf(foundAppointment.getOrderId()));
         if(findOrder.isPresent())
         {
            Order order = findOrder.get();
            order.setStatus(3);
            orderRepository.save(order);
         }
         appointmentRepository.save(foundAppointment);
      }

      return "redirect:/receptionistsPanel";
   }

   @PostMapping("/completeImaging")
   public String completeImaging(@ModelAttribute("order") Order order, Model model)
   {
      Optional<Order> findOrder = orderRepository.findById(Long.valueOf(order.getId()));
      if(findOrder.isPresent())
      {
         Order foundOrder = findOrder.get();
         foundOrder.setStatus(4);
         orderRepository.save(foundOrder);
      }
      
      return "redirect:/techPanel";
   }
}